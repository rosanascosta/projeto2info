create database trabalho_web_programacao;

use trabalho_web_programacao;

create table usuarios (

    id int auto_increment primary key,
    nome varchar(100),
    tipo enum("administrador", "usuario_comum") not null,
    senha varchar(50),
    CPF varchar(50)

);


create table resistores (

    id int auto_increment primary key,
    resistencia_eletrica VARCHAR(100),
    tolerancia varchar(50),
    quantidade_estoque int

);


create table transistores (

    id int auto_increment primary key,
    modelo varchar(100),
    quantidade_estoque int

);


create table fusiveis (

    id int auto_increment primary key,
    amperagem varchar(50),
    quantidade_estoque int

);


create table capacitores (

    id int auto_increment primary key,
    voltagem varchar(50),
    especificacoes_uF varchar(50),
    quantidade_estoque int

);


create table fontes (

    id int auto_increment primary key,
    voltagem varchar(50),
    amperagem varchar(50),
    quantidade_estoque int

);


create table Dados_do_cliente (

    id int auto_increment primary key,
    nome varchar(50),
    CPF varchar(50),
    finalidade varchar(255),
    data date,
    peca varchar(30),
    quantidade int

);



insert into transistores (modelo , quantidade_estoque) values
("TIP41", 100),
("TIP31", 100),
("IRF640", 100);


insert into resistores (resistencia_eletrica , tolerancia , quantidade_estoque) values
("240 Ω", "20%", 100),
("1000 Ω", "20%", 100),
("2000 Ω", "10%", 100);


insert into fontes (voltagem , amperagem , quantidade_estoque) values
("12 V", "2 A", 100),
("6 V", "5 A", 100),
("10 V", "1 A", 100);


insert into fusiveis (amperagem , quantidade_estoque) values
("10 A", 100),
("20 A", 100),
("25 A", 100),
("15 A", 100);


insert into capacitores (voltagem, especificacoes_uF , quantidade_estoque) values
("12 V", "1000 uF", 100),
("16 V", "1500 uF", 100),
("6.3 V", "1800 uF", 100);


insert into usuarios (nome, tipo, senha, CPF) values
("Miguel", "administrador", "cefet123","059.806.320-00"),
("nicolas", "usuario_comum", "cefet123","002.035.410-06");



#drop database trabalho_web_programacao;