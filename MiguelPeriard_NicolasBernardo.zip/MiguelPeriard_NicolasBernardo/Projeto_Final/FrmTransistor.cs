﻿using Microsoft.VisualBasic.Logging;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Projeto_Final
{
    public partial class FrmTransistor : Form
    {
        public FrmTransistor()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string modelo = textBox1.Text.Trim().ToUpper();

            if (string.IsNullOrWhiteSpace(modelo))
            {
                MessageBox.Show("Digite o modelo do transistor.");
                textBox1.Focus();
                return;
            }


            FrmLocalização localizacao = new FrmLocalização("transistor", modelo);
            PosicaoJanela.Copiar(this, localizacao);
            localizacao.Show();
            Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            FrmEscolha Escolha = new FrmEscolha();
            PosicaoJanela.Copiar(this, Escolha);
            Escolha.Show();
            Close();
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }
    }
}
