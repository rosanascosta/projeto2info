﻿namespace Projeto_Final
{
    partial class FrmFonteAdd
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmFonteAdd));
            textBox6 = new TextBox();
            button3 = new Button();
            label7 = new Label();
            label6 = new Label();
            textBox4 = new TextBox();
            textBox2 = new TextBox();
            dataGridView1 = new DataGridView();
            button2 = new Button();
            button1 = new Button();
            textBox1 = new TextBox();
            groupBox4 = new GroupBox();
            groupBox5 = new GroupBox();
            groupBox6 = new GroupBox();
            groupBox7 = new GroupBox();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            groupBox4.SuspendLayout();
            groupBox5.SuspendLayout();
            groupBox6.SuspendLayout();
            groupBox7.SuspendLayout();
            SuspendLayout();
            // 
            // textBox6
            // 
            textBox6.Location = new Point(6, 23);
            textBox6.Name = "textBox6";
            textBox6.Size = new Size(187, 26);
            textBox6.TabIndex = 66;
            //textBox6.TextChanged += textBox6_TextChanged;
            // 
            // button3
            // 
            button3.BackColor = Color.DodgerBlue;
            button3.Font = new Font("Times New Roman", 12F, FontStyle.Bold);
            button3.Location = new Point(694, 402);
            button3.Name = "button3";
            button3.Size = new Size(94, 26);
            button3.TabIndex = 65;
            button3.Text = "Voltar";
            button3.UseVisualStyleBackColor = false;
            button3.Click += button3_Click;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Location = new Point(194, 27);
            label7.Name = "label7";
            label7.Size = new Size(20, 19);
            label7.TabIndex = 62;
            label7.Text = "A";
            //label7.Click += label7_Click;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(189, 30);
            label6.Name = "label6";
            label6.Size = new Size(24, 19);
            label6.TabIndex = 61;
            label6.Text = " V";
            // 
            // textBox4
            // 
            textBox4.Location = new Point(6, 23);
            textBox4.Name = "textBox4";
            textBox4.Size = new Size(182, 26);
            textBox4.TabIndex = 54;
            //textBox4.TextChanged += textBox4_TextChanged;
            // 
            // textBox2
            // 
            textBox2.Location = new Point(6, 22);
            textBox2.Name = "textBox2";
            textBox2.Size = new Size(180, 26);
            textBox2.TabIndex = 52;
            //textBox2.TextChanged += textBox2_TextChanged;
            // 
            // dataGridView1
            // 
            dataGridView1.BackgroundColor = SystemColors.ButtonHighlight;
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView1.Location = new Point(12, 12);
            dataGridView1.Name = "dataGridView1";
            dataGridView1.Size = new Size(776, 230);
            dataGridView1.TabIndex = 51;
            //dataGridView1.CellContentClick += dataGridView1_CellContentClick;
            // 
            // button2
            // 
            button2.BackColor = Color.DodgerBlue;
            button2.Font = new Font("Times New Roman", 12F, FontStyle.Bold);
            button2.Location = new Point(694, 341);
            button2.Name = "button2";
            button2.Size = new Size(94, 26);
            button2.TabIndex = 50;
            button2.Text = "Excluir";
            button2.UseVisualStyleBackColor = false;
            button2.Click += button2_Click;
            // 
            // button1
            // 
            button1.BackColor = Color.DodgerBlue;
            button1.Font = new Font("Times New Roman", 12F, FontStyle.Bold);
            button1.Location = new Point(694, 277);
            button1.Name = "button1";
            button1.Size = new Size(94, 27);
            button1.TabIndex = 49;
            button1.Text = "Adicionar";
            button1.UseVisualStyleBackColor = false;
            button1.Click += button1_Click;
            // 
            // textBox1
            // 
            textBox1.Location = new Point(8, 23);
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(178, 26);
            textBox1.TabIndex = 48;
            //textBox1.TextChanged += textBox1_TextChanged;
            // 
            // groupBox4
            // 
            groupBox4.Controls.Add(textBox2);
            groupBox4.Font = new Font("Times New Roman", 12F, FontStyle.Bold);
            groupBox4.Location = new Point(12, 319);
            groupBox4.Name = "groupBox4";
            groupBox4.Size = new Size(215, 59);
            groupBox4.TabIndex = 0;
            groupBox4.TabStop = false;
            groupBox4.Text = "id";
            // 
            // groupBox5
            // 
            groupBox5.Controls.Add(textBox1);
            groupBox5.Controls.Add(label6);
            groupBox5.Font = new Font("Times New Roman", 12F, FontStyle.Bold);
            groupBox5.Location = new Point(12, 252);
            groupBox5.Name = "groupBox5";
            groupBox5.Size = new Size(215, 59);
            groupBox5.TabIndex = 0;
            groupBox5.TabStop = false;
            groupBox5.Text = "Voltagem";
            // 
            // groupBox6
            // 
            groupBox6.Controls.Add(textBox4);
            groupBox6.Controls.Add(label7);
            groupBox6.Font = new Font("Times New Roman", 12F, FontStyle.Bold);
            groupBox6.Location = new Point(236, 252);
            groupBox6.Name = "groupBox6";
            groupBox6.Size = new Size(215, 59);
            groupBox6.TabIndex = 0;
            groupBox6.TabStop = false;
            groupBox6.Text = "Amperagem";
            // 
            // groupBox7
            // 
            groupBox7.Controls.Add(textBox6);
            groupBox7.Font = new Font("Times New Roman", 12F, FontStyle.Bold);
            groupBox7.Location = new Point(463, 252);
            groupBox7.Name = "groupBox7";
            groupBox7.Size = new Size(215, 59);
            groupBox7.TabIndex = 0;
            groupBox7.TabStop = false;
            groupBox7.Text = "Quantidade";
            // 
            // FrmFonteAdd
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.SteelBlue;
            ClientSize = new Size(800, 450);
            Controls.Add(groupBox4);
            Controls.Add(groupBox5);
            Controls.Add(groupBox7);
            Controls.Add(groupBox6);
            Controls.Add(button3);
            Controls.Add(dataGridView1);
            Controls.Add(button2);
            Controls.Add(button1);
            Icon = (Icon)resources.GetObject("$this.Icon");
            MaximizeBox = false;
            MaximumSize = new Size(816, 489);
            MinimumSize = new Size(816, 489);
            Name = "FrmFonteAdd";
            Text = "Fonte Adicionar";
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            groupBox4.ResumeLayout(false);
            groupBox4.PerformLayout();
            groupBox5.ResumeLayout(false);
            groupBox5.PerformLayout();
            groupBox6.ResumeLayout(false);
            groupBox6.PerformLayout();
            groupBox7.ResumeLayout(false);
            groupBox7.PerformLayout();
            ResumeLayout(false);
        }

        #endregion
        private TextBox textBox6;
        private Button button3;
        private Label label7;
        private Label label6;
        private TextBox textBox4;
        private TextBox textBox2;
        private DataGridView dataGridView1;
        private Button button2;
        private Button button1;
        private TextBox textBox1;
        private GroupBox groupBox4;
        private GroupBox groupBox5;
        private GroupBox groupBox6;
        private GroupBox groupBox7;
    }
}