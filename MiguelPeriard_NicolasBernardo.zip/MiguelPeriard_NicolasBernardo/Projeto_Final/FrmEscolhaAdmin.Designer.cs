﻿namespace Projeto_Final
{
    partial class FrmEscolhaAdmin
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmEscolhaAdmin));
            button6 = new Button();
            label6 = new Label();
            button7 = new Button();
            label7 = new Label();
            label8 = new Label();
            label9 = new Label();
            button8 = new Button();
            label10 = new Label();
            button1 = new Button();
            label1 = new Label();
            SuspendLayout();
            // 
            // button6
            // 
            button6.BackColor = Color.DodgerBlue;
            button6.BackgroundImage = (Image)resources.GetObject("button6.BackgroundImage");
            button6.BackgroundImageLayout = ImageLayout.Zoom;
            button6.Location = new Point(223, 17);
            button6.Name = "button6";
            button6.Size = new Size(162, 419);
            button6.TabIndex = 20;
            button6.UseVisualStyleBackColor = false;
            button6.Click += button6_Click;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.BackColor = Color.DodgerBlue;
            label6.Font = new Font("Times New Roman", 12F, FontStyle.Bold);
            label6.ForeColor = SystemColors.ActiveCaptionText;
            label6.Location = new Point(259, 379);
            label6.Name = "label6";
            label6.Size = new Size(73, 19);
            label6.TabIndex = 21;
            label6.Text = "Adicionar";
            // 
            // button7
            // 
            button7.BackColor = Color.DodgerBlue;
            button7.BackgroundImage = (Image)resources.GetObject("button7.BackgroundImage");
            button7.BackgroundImageLayout = ImageLayout.Zoom;
            button7.Location = new Point(419, 19);
            button7.Name = "button7";
            button7.Size = new Size(158, 419);
            button7.TabIndex = 22;
            button7.UseVisualStyleBackColor = false;
            button7.Click += button7_Click;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.BackColor = Color.DodgerBlue;
            label7.Font = new Font("Times New Roman", 12F, FontStyle.Bold);
            label7.ForeColor = SystemColors.ActiveCaptionText;
            label7.Location = new Point(441, 379);
            label7.Name = "label7";
            label7.Size = new Size(73, 19);
            label7.TabIndex = 23;
            label7.Text = "Adicionar";
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.BackColor = Color.DodgerBlue;
            label8.Font = new Font("Times New Roman", 12F, FontStyle.Bold);
            label8.ForeColor = SystemColors.ActiveCaptionText;
            label8.Location = new Point(441, 398);
            label8.Name = "label8";
            label8.Size = new Size(96, 19);
            label8.TabIndex = 24;
            label8.Text = "componentes";
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.BackColor = Color.DodgerBlue;
            label9.Font = new Font("Times New Roman", 12F, FontStyle.Bold);
            label9.ForeColor = SystemColors.ActiveCaptionText;
            label9.Location = new Point(259, 398);
            label9.Name = "label9";
            label9.Size = new Size(58, 19);
            label9.TabIndex = 25;
            label9.Text = "usuário";
            // 
            // button8
            // 
            button8.BackColor = Color.DodgerBlue;
            button8.BackgroundImage = (Image)resources.GetObject("button8.BackgroundImage");
            button8.BackgroundImageLayout = ImageLayout.Center;
            button8.ForeColor = SystemColors.ActiveCaptionText;
            button8.Location = new Point(615, 18);
            button8.Name = "button8";
            button8.Size = new Size(164, 420);
            button8.TabIndex = 26;
            button8.UseVisualStyleBackColor = false;
            button8.Click += button8_Click;
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.BackColor = Color.DodgerBlue;
            label10.Font = new Font("Times New Roman", 12F, FontStyle.Bold);
            label10.ForeColor = SystemColors.ActiveCaptionText;
            label10.Location = new Point(682, 398);
            label10.Name = "label10";
            label10.Size = new Size(36, 19);
            label10.TabIndex = 27;
            label10.Text = "Sair";
            // 
            // button1
            // 
            button1.BackColor = Color.DodgerBlue;
            button1.BackgroundImage = (Image)resources.GetObject("button1.BackgroundImage");
            button1.BackgroundImageLayout = ImageLayout.Zoom;
            button1.Location = new Point(22, 18);
            button1.Name = "button1";
            button1.Size = new Size(158, 418);
            button1.TabIndex = 28;
            button1.UseVisualStyleBackColor = false;
            button1.Click += button1_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.BackColor = Color.DodgerBlue;
            label1.Font = new Font("Times New Roman", 12F, FontStyle.Bold);
            label1.ForeColor = SystemColors.ActiveCaptionText;
            label1.Location = new Point(53, 398);
            label1.Name = "label1";
            label1.Size = new Size(96, 19);
            label1.TabIndex = 29;
            label1.Text = "Empréstimos";
            // 
            // FrmEscolhaAdmin
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.SteelBlue;
            ClientSize = new Size(800, 450);
            Controls.Add(label1);
            Controls.Add(button1);
            Controls.Add(label10);
            Controls.Add(button8);
            Controls.Add(label9);
            Controls.Add(label8);
            Controls.Add(label7);
            Controls.Add(button7);
            Controls.Add(label6);
            Controls.Add(button6);
            Icon = (Icon)resources.GetObject("$this.Icon");
            MaximizeBox = false;
            MaximumSize = new Size(816, 489);
            MinimumSize = new Size(816, 489);
            Name = "FrmEscolhaAdmin";
            Text = "EscolhaAdmin";
            Load += FrmEscolhaAdmin_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private Button button6;
        private Label label6;
        private Button button7;
        private Label label7;
        private Label label8;
        private Label label9;
        private Button button8;
        private Label label10;
        private Button button1;
        private Label label1;
    }
}