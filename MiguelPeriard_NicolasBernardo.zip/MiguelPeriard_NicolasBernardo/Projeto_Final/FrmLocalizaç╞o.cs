﻿using Microsoft.VisualBasic.Logging;
using MySql.Data.MySqlClient;
using System;
using System.Data;
using System.Windows.Forms;

namespace Projeto_Final
{
    public partial class FrmLocalização : Form
    {

        private string tipoComponente;
        private string valorPrincipal;
        private string valorSecundario;
        private int quantidade;

        public FrmLocalização(string tipoComponente, string valorPrincipal, string valorSecundario = null)
        {

            InitializeComponent();

            this.tipoComponente = tipoComponente.ToLower();
            this.valorPrincipal = valorPrincipal;
            this.valorSecundario = valorSecundario;
            this.quantidade = 0;

            label1.Text = $"Componente: {tipoComponente}";

            CarregarComponentes();
        
        }

        public void AtualizarGrid()
        {
            CarregarComponentes();
        }

        private void CarregarComponentes()
        {

            string conexaoString = "server=localhost;database=trabalho_web_programacao;uid=root;pwd=;";

            using (MySqlConnection conn = new MySqlConnection(conexaoString))
            {

                conn.Open();

                string sql = "";
                MySqlCommand cmd = new MySqlCommand();
                cmd.Connection = conn;


                switch (tipoComponente)
                {

                    case "fusivel":
                        sql = "select * from fusiveis where amperagem = @valor";
                        cmd.Parameters.AddWithValue("@valor", valorPrincipal + " A");
                        break;


                    case "resistor":
                        sql = "select * from resistores where resistencia_eletrica like @valor";
                        cmd.Parameters.AddWithValue("@valor", valorPrincipal + "%");
                        break;


                    case "transistor":
                        sql = "select * from transistores where modelo = @modelo";
                        cmd.Parameters.AddWithValue("@modelo", valorPrincipal.Trim().ToUpper());
                        break;


                    case "fonte":
                        sql = "select * from fontes where voltagem = @vol and amperagem = @amp";
                        cmd.Parameters.AddWithValue("@vol", valorPrincipal);
                        cmd.Parameters.AddWithValue("@amp", valorSecundario);
                        break;


                    case "capacitor":
                        sql = "select * from capacitores where voltagem = @vol and especificacoes_uF = @cap";
                        cmd.Parameters.AddWithValue("@vol", valorPrincipal);
                        cmd.Parameters.AddWithValue("@cap", valorSecundario);
                        break;

                    default:

                        MessageBox.Show("Tipo de componente inválido!");
                        return;
                }

                cmd.CommandText = sql;
                
                MySqlDataAdapter da = new MySqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                
                da.Fill(dt);

                if (dt.Rows.Count == 0)
                {

                    MessageBox.Show("Nenhum componente encontrado!");
                    dataGridView1.DataSource = null;
                    return;
                
                }

                dataGridView1.DataSource = dt;
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {

            if (dataGridView1.Rows.Count == 0)
            {
                MessageBox.Show("Nenhum componente selecionado.");
                return;
            }


            int idComponente = Convert.ToInt32(dataGridView1.Rows[0].Cells["id"].Value);
            string peca = tipoComponente;

            if (!int.TryParse(textBox1.Text, out int quantidade) || quantidade <= 0)
            {

                MessageBox.Show("Digite uma quantidade válida.");
                return;
            
            }

            string nomeTabela = peca switch
            {

                "resistor" => "resistores",
                "fusivel" => "fusiveis",
                "transistor" => "transistores",
                "fonte" => "fontes",
                "capacitor" => "capacitores",
                _ => ""
            
            };

            if (string.IsNullOrEmpty(nomeTabela))
            {

                MessageBox.Show("Peça inválida.");
                return;
            
            }

            int estoqueAtual;
            using (var conn = new MySqlConnection("server=localhost;database=trabalho_web_programacao;uid=root;pwd=;"))
            {
              
                conn.Open();
                using (var cmdCheck = new MySqlCommand($"select quantidade_estoque from {nomeTabela} where id = @id", conn))
                {

                    cmdCheck.Parameters.AddWithValue("@id", idComponente);
                    estoqueAtual = Convert.ToInt32(cmdCheck.ExecuteScalar());
                
                }

            }

            if (quantidade > estoqueAtual)
            {

                MessageBox.Show($"Estoque insuficiente! Apenas {estoqueAtual} disponível.");
                return;
            
            }

            FrmFinalizar Finalizar = new FrmFinalizar(peca, quantidade, idComponente, this);
            PosicaoJanela.Copiar(this, Finalizar);
            Finalizar.Show();
            Close();
        
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
        }

        private void button1_Click(object sender, EventArgs e)
        {

            FrmEscolha escolha = new FrmEscolha();
            PosicaoJanela.Copiar(this, escolha);
            escolha.Show();
            Close();
        
        }
    }
}
