﻿using Microsoft.VisualBasic.Logging;
using MySql.Data.MySqlClient;
using System;
using System.Data;
using System.Linq;
using System.Windows.Forms;

namespace Projeto_Final
{
    public partial class FrmAddUsuario : Form
    {
        string conexaoString = "server=localhost;database=trabalho_web_programacao;uid=root;pwd=;";

        public FrmAddUsuario()
        {
            InitializeComponent();

            comboBox1.Items.Add("administrador");
            comboBox1.Items.Add("usuario_comum");
            comboBox1.DropDownStyle = ComboBoxStyle.DropDownList;

            CarregarUsuarios();

           
            textBox5.KeyPress += textBox5_KeyPress;
            textBox5.TextChanged += textBox5_TextChanged;
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            
            comboBox1.DropDownStyle = ComboBoxStyle.DropDownList;

            if (comboBox1.Items.Count == 0)
            {

                comboBox1.Items.Add("administrador");
                comboBox1.Items.Add("usuario_comum");
           
            }

            if (comboBox1.Items.Count > 0 && comboBox1.SelectedIndex == -1) comboBox1.SelectedIndex = 0;

            CarregarUsuarios();
        }

      
        private void button1_Click(object sender, EventArgs e)
        {
            using (MySqlConnection conn = new MySqlConnection(conexaoString))
            {

                if (string.IsNullOrWhiteSpace(textBox1.Text))
                {

                    MessageBox.Show("preencha o nome do usuário.");
                    textBox1.Focus();
                    return;
                
                }

                if (comboBox1.SelectedIndex == -1)
                {

                    MessageBox.Show("selecione o tipo de usuário.");
                    comboBox1.Focus();
                    return;
                
                }

                if (string.IsNullOrWhiteSpace(textBox4.Text))
                {

                    MessageBox.Show("senha obrigatória.");
                    textBox4.Focus();
                    return;
                
                }

                if (string.IsNullOrWhiteSpace(textBox5.Text) || textBox5.Text.Length != 14)
                {

                    MessageBox.Show("preencha um cpf válido.");
                    textBox5.Focus();
                    return;
                
                }

                conn.Open();

                string sql = "insert into usuarios (nome, tipo, senha, cpf) values (@nome, @tipo, @senha, @cpf)";
                MySqlCommand cmd = new MySqlCommand(sql, conn);

                cmd.Parameters.AddWithValue("@nome", textBox1.Text);
                cmd.Parameters.AddWithValue("@tipo", comboBox1.SelectedItem.ToString());
                cmd.Parameters.AddWithValue("@senha", textBox4.Text);
                cmd.Parameters.AddWithValue("@cpf", textBox5.Text);

                cmd.ExecuteNonQuery();
                MessageBox.Show("usuário adicionado com sucesso!");

                CarregarUsuarios();

                textBox1.Clear();
                textBox4.Clear();
                textBox5.Clear();
                comboBox1.SelectedIndex = -1;
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            using (MySqlConnection conn = new MySqlConnection(conexaoString))
            {

                if (string.IsNullOrWhiteSpace(textBox2.Text))
                {

                    MessageBox.Show("preencha o id do usuário.");
                    textBox2.Focus();
                    return;

                }

                if (string.IsNullOrWhiteSpace(textBox3.Text))
                {

                    MessageBox.Show("preencha o nome do usuário.");
                    textBox3.Focus();
                    return;

                }

                conn.Open();

                string sql = "delete from usuarios where id = @id and nome = @nome";

                MySqlCommand cmd = new MySqlCommand(sql, conn);
                
                cmd.Parameters.AddWithValue("@id", textBox2.Text);
                cmd.Parameters.AddWithValue("@nome", textBox3.Text);

                int rowsAffected = cmd.ExecuteNonQuery();


                if (rowsAffected > 0) 
                { 

                    MessageBox.Show("usuário excluído com sucesso!");
                
                }
                else
                {

                    MessageBox.Show("usuário não encontrado ou dados incorretos. verifique o id e o nome.");
                
                }

                   

                
                CarregarUsuarios();
                textBox2.Clear();
                textBox3.Clear();
            }
        }

    
        private void CarregarUsuarios()
        {
            using (MySqlConnection conn = new MySqlConnection(conexaoString))
            {
                
                conn.Open();

                MySqlDataAdapter da = new MySqlDataAdapter("select id, nome, tipo, cpf from usuarios", conn);
                DataTable dt = new DataTable();
                da.Fill(dt);
                dataGridView1.DataSource = dt;
            
            }
        }

       
        private void button3_Click(object sender, EventArgs e)
        {

            FrmEscolhaAdmin Escolha = new FrmEscolhaAdmin();
            PosicaoJanela.Copiar(this, Escolha);
            Escolha.Show();
            this.Hide();
        
        }

       
        private void textBox5_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsDigit(e.KeyChar) && e.KeyChar != (char)Keys.Back) e.Handled = true;
        }

        
        private void textBox5_TextChanged(object sender, EventArgs e)
        {

            string texto = new string(textBox5.Text.Where(char.IsDigit).ToArray());

            if (texto.Length > 11) texto = texto.Substring(0, 11);


            if (texto.Length >= 3 && texto.Length <= 5)
                
                texto = texto.Insert(3, ".");
            
            else if (texto.Length > 5 && texto.Length <= 8)
                
                texto = texto.Insert(3, ".").Insert(7, ".");
            
            else if (texto.Length > 8)

                texto = texto.Insert(3, ".").Insert(7, ".").Insert(11, "-");

            
            
            textBox5.TextChanged -= textBox5_TextChanged;
            
            textBox5.Text = texto;
            
            textBox5.SelectionStart = textBox5.Text.Length;
            
            textBox5.TextChanged += textBox5_TextChanged;
        }
    }
}
