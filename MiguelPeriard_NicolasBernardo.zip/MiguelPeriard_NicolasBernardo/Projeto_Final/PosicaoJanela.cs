﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Projeto_Final
{
    internal class PosicaoJanela
    {
        public static void Copiar(Form origem, Form destino)
        {
            destino.StartPosition = FormStartPosition.Manual;
            destino.Location = origem.Location;
        }
    }
}
