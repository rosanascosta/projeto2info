﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Reflection.Emit;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Projeto_Final
{
    public partial class FrmResistoresCores : Form
    {

        public FrmResistoresCores()
        {
            InitializeComponent();
        }

        int i = 01;
        int j = 01;
        int k = 01;
        int c = 01;

        public enum CorResistor
        {
            Preto = 0,
            Marrom = 1,
            Vermelho = 2,
            Laranja = 3,
            Amarelo = 4,
            Verde = 5,
            Azul = 6,
            Violeta = 7,
            Cinza = 8,
            Branco = 9,
            Dourado = 10,
            Prata = 11
        }


        private Color ObterCor(int valor)
        {
            return valor switch
            {
                0 => Color.Black,
                1 => Color.Brown,
                2 => Color.Red,
                3 => Color.Orange,
                4 => Color.Yellow,
                5 => Color.Green,
                6 => Color.Blue,
                7 => Color.Violet,
                8 => Color.Gray,
                9 => Color.White,
                10 => Color.Gold,
                11 => Color.Silver,
                _ => Color.Transparent
            };
        }


        double ObterMultiplicador(CorResistor cor)
        {
            return cor switch
            {
                CorResistor.Preto => 1,
                CorResistor.Marrom => 10,
                CorResistor.Vermelho => 100,
                CorResistor.Laranja => 1000,
                CorResistor.Amarelo => 10000,
                CorResistor.Verde => 100000,
                CorResistor.Azul => 1000000,
                CorResistor.Dourado => 0.1,
                CorResistor.Prata => 0.01,
                _ => 1
            };
        }

        string ObterTolerancia(CorResistor cor)
        {
            return cor switch
            {
                CorResistor.Marrom => "1%",
                CorResistor.Vermelho => "2%",
                CorResistor.Dourado => "5%",
                CorResistor.Prata => "10%",
                _ => "20%"
            };
        }


        double CalcularResistencia(CorResistor f1, CorResistor f2, CorResistor f3)
        {
            int d1 = (int)f1;
            int d2 = (int)f2;


            return ((d1 * 10) + d2) * ObterMultiplicador(f3);
        }
        private void button2_Click(object sender, EventArgs e)
        {
            i = (i + 1) % 12;
            button2.BackColor = ObterCor(i);
        }



        private void FrmResistoresCores_Load(object sender, EventArgs e)
        {

        }

        private void button16_Click(object sender, EventArgs e)
        {
            i++;
            if (i == 1)
            {
                button2.Visible = true;
                button2.BackColor = Color.White;
            }
        }

        private void button17_Click(object sender, EventArgs e)
        {

        }

        private void button10_Click(object sender, EventArgs e)
        {
            j = (j + 1) % 12;
            button10.BackColor = ObterCor(j);
        }

        private void button3_Click(object sender, EventArgs e)
        {
            k = (k + 1) % 12;
            button3.BackColor = ObterCor(k);
        }

        private void button4_Click(object sender, EventArgs e)
        {
            c = (c + 1) % 12;
            button4.BackColor = ObterCor(c);
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button6_Click_1(object sender, EventArgs e)
        {
            CorResistor f1 = (CorResistor)i;
            CorResistor f2 = (CorResistor)j;
            CorResistor f3 = (CorResistor)k;
            CorResistor f4 = (CorResistor)c;

            double resistencia = CalcularResistencia(f1, f2, f3);
            string tolerancia = ObterTolerancia(f4);

            label1.Text = $"{resistencia} Ω {tolerancia}";


            string resistenciaStr = resistencia.ToString("0.##", CultureInfo.InvariantCulture);
            string toleranciaStr = tolerancia;


            FrmLocalização Localizacao = new FrmLocalização("resistor", resistenciaStr, toleranciaStr);
            PosicaoJanela.Copiar(this, Localizacao);
            Localizacao.Show();
            Close();

        }


        private void button15_Click(object sender, EventArgs e)
        {

        }

        private void button16_Click_1(object sender, EventArgs e)
        {
            FrmResistor cores = new FrmResistor();
            PosicaoJanela.Copiar(this, cores);
            cores.Show();
            Close();
        }
    }
}
