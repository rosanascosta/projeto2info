﻿using Microsoft.VisualBasic.Logging;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Projeto_Final
{
    public partial class FrmEscolha : Form
    {
        public FrmEscolha()
        {
            InitializeComponent();
        }

        private void FrmEscolha_Load(object sender, EventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {
            FrmTransistor Transistor = new FrmTransistor();
            PosicaoJanela.Copiar(this, Transistor);
            Transistor.Show();
            Close();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            FrmFusivel Fusivel = new FrmFusivel();
            PosicaoJanela.Copiar(this, Fusivel);
            Fusivel.Show();
            Close();
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            FrmResistor Resistor = new FrmResistor();
            PosicaoJanela.Copiar(this, Resistor);
            Resistor.Show();
            Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            FrmCapacitor capacitor = new FrmCapacitor();
            PosicaoJanela.Copiar(this, capacitor);
            capacitor.Show();
            Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            FrmFonte Fonte = new FrmFonte();
            PosicaoJanela.Copiar(this, Fonte);
            Fonte.Show();
            Close();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            FrmRegistro Escolha = new FrmRegistro();
            PosicaoJanela.Copiar(this, Escolha);
            Escolha.Show();
            Close();
        }
    }
}
