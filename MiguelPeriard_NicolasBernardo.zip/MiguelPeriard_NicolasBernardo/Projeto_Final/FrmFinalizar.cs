﻿using Microsoft.VisualBasic.Logging;
using MySql.Data.MySqlClient;
using System;
using System.Data;
using System.Linq;
using System.Text.RegularExpressions;
using System.Windows.Forms;

namespace Projeto_Final
{
    public partial class FrmFinalizar : Form
    {
        private string peca;
        private int quantidade;
        private int idComponente;
        private FrmLocalização frmLocal;

        public FrmFinalizar(string peca, int quantidade, int idComponente, FrmLocalização frmLocal)
        {
            InitializeComponent();
            this.peca = peca;
            this.quantidade = quantidade;
            this.idComponente = idComponente;
            this.frmLocal = frmLocal;

            textBox4.Text = ClasseNome.NomeUsuario;
            textBox4.ReadOnly = true;

            textBox1.Text = ClasseCPF.CPF;
            textBox1.ReadOnly = true;
        }

        private string ObterNomeTabela(string peca)
        {
            switch (peca.ToLower())
            {
                case "resistor": return "resistores";
                case "fusivel": return "fusiveis";
                case "transistor": return "transistores";
                case "fonte": return "fontes";
                case "capacitor": return "capacitores";
                default: throw new Exception("Peça inválida.");
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string nome = textBox4.Text.Trim();
            string cpf = textBox1.Text.Trim();
            string finalidade = textBox2.Text.Trim();

            if (string.IsNullOrWhiteSpace(nome) || string.IsNullOrWhiteSpace(cpf) || string.IsNullOrWhiteSpace(finalidade))
            {
                MessageBox.Show("Preencha todos os campos!");
                return;
            }

            if (!Regex.IsMatch(cpf, @"^\d{3}\.\d{3}\.\d{3}\-\d{2}$"))
            {
                MessageBox.Show("O CPF deve estar no formato ###.###.###-##");
                textBox1.Focus();
                return;
            }

            string cpfNumeros = new string(cpf.Where(char.IsDigit).ToArray());
            if (cpfNumeros.Length != 11)
            {
                MessageBox.Show("O CPF deve conter exatamente 11 dígitos numéricos.");
                textBox1.Focus();
                return;
            }

            string nomeTabela = ObterNomeTabela(peca);

            try
            {
                using (var conn = new MySqlConnection("server=localhost;database=trabalho_web_programacao;uid=root;pwd=;"))
                {
                    conn.Open();

                    
                    string sqlInsert = @"insert into Dados_do_cliente (nome, CPF, finalidade, data, peca, quantidade) values (@nome, @cpf, @finalidade, @data, @peca, @quantidade)";
                    using (var cmd = new MySqlCommand(sqlInsert, conn))
                    {
                        cmd.Parameters.AddWithValue("@nome", nome);
                        cmd.Parameters.AddWithValue("@cpf", cpf);
                        cmd.Parameters.AddWithValue("@finalidade", finalidade);
                        cmd.Parameters.AddWithValue("@data", DateTime.Now.Date);
                        cmd.Parameters.AddWithValue("@peca", peca);
                        cmd.Parameters.AddWithValue("@quantidade", quantidade);
                        cmd.ExecuteNonQuery();
                    }

                    
                    string sqlUpdate = $"update {nomeTabela} set quantidade_estoque = quantidade_estoque - @qtd where id = @idComponente";
                    
                    using (var cmdUpdate = new MySqlCommand(sqlUpdate, conn))
                    {
                        cmdUpdate.Parameters.AddWithValue("@qtd", quantidade);
                        cmdUpdate.Parameters.AddWithValue("@idComponente", idComponente);
                        cmdUpdate.ExecuteNonQuery();
                    }

                    MessageBox.Show("Empréstimo registrado com sucesso!");
                }

               
                frmLocal.AtualizarGrid();

                
                FrmEscolha Escolha = new FrmEscolha();
                PosicaoJanela.Copiar(this, Escolha);
                Escolha.Show();
                this.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erro ao registrar empréstimo: " + ex.Message);
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            FrmEscolha Escolha = new FrmEscolha();
            PosicaoJanela.Copiar(this, Escolha);
            Escolha.Show();
            Close();
        }
    }
}
