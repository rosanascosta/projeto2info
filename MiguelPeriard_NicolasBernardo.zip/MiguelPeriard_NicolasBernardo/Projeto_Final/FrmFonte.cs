﻿using Microsoft.VisualBasic.Logging;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Projeto_Final
{
    public partial class FrmFonte : Form
    {
        public FrmFonte()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(textBox1.Text))
            {
                MessageBox.Show("Digite a voltagem da fonte.");
                textBox1.Focus();
                return;
            }

            
            if (string.IsNullOrWhiteSpace(textBox2.Text))
            {
                MessageBox.Show("Digite a amperagem.");
                textBox2.Focus();
                return;
            }

            string voltagem = textBox1.Text.Trim() + " V";
            string amperagem = textBox2.Text.Trim() + " A";

            FrmLocalização Localizacao = new FrmLocalização("fonte", voltagem, amperagem);
            PosicaoJanela.Copiar(this, Localizacao);
            Localizacao.Show();
            Close();
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void button2_Click_1(object sender, EventArgs e)
        {
            FrmEscolha Escolha = new FrmEscolha();
            PosicaoJanela.Copiar(this, Escolha);
            Escolha.Show();
            Close();
        }
    }
}
