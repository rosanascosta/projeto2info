﻿using Microsoft.VisualBasic.Logging;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Projeto_Final
{
    public partial class FrmCapacitor : Form
    {
        private string voltagem;
        private string capacitancia;

        public FrmCapacitor()
        {
            InitializeComponent();

            textBox1.Text = "";
            textBox2.Text = "";
        }
        private void FrmCapacitorPronto_Load(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            FrmEscolha Escolha = new FrmEscolha();
            PosicaoJanela.Copiar(this, Escolha);
            Escolha.Show();
            Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            
            if (string.IsNullOrWhiteSpace(textBox1.Text))
            {
                MessageBox.Show("Digite a voltagem do capacitor.");
                textBox1.Focus();
                return;
            }

            voltagem = textBox1.Text.Trim().ToUpper() + " V";

            
            if (!double.TryParse(textBox2.Text, NumberStyles.Any, CultureInfo.InvariantCulture, out double cap))
            {
                MessageBox.Show("Digite uma capacitância válida.");
                textBox2.Focus();
                return;
            }

            capacitancia = cap.ToString(CultureInfo.InvariantCulture) + " uF";


            FrmLocalização Localizacao = new FrmLocalização("capacitor", voltagem, capacitancia);
            PosicaoJanela.Copiar(this, Localizacao);
            Localizacao.Show();
            Close();
        }

        private void label5_Click(object sender, EventArgs e)
        {

        }
    }

}
