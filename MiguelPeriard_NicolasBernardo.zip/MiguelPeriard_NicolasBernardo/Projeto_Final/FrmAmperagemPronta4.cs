﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Projeto_Final
{
    public partial class FrmAmperagemPronta4 : Form
    {
        public FrmAmperagemPronta4()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            double valor;


            if (!double.TryParse(textBox1.Text, out valor))
            {
                MessageBox.Show("Digite apenas números válidos.");
                return;
            }


            double arredondado = Math.Ceiling(valor / 5) * 5;


            string valorArredondado = arredondado.ToString("0", CultureInfo.InvariantCulture);


            FrmLocalização localizacao = new FrmLocalização("fusivel", valorArredondado);
            PosicaoJanela.Copiar(this, localizacao);
            localizacao.Show();
            this.Hide();
        }

        private void FrmAmperagemPronta4_Load(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            FrmFusivel cores = new FrmFusivel();
            PosicaoJanela.Copiar(this, cores );
            cores.Show();
            Close();
        }
    }
}

