﻿using Microsoft.VisualBasic.Logging;
using MySql.Data.MySqlClient;
using System;
using System.Data;
using System.Windows.Forms;

namespace Projeto_Final
{
    public partial class FrmFusivelAdd : Form
    {
        string conexaoString = "server=localhost;database=trabalho_web_programacao;uid=root;pwd=;";

        public FrmFusivelAdd()
        {

            InitializeComponent();
            CarregarFusivel();
        
        }

        private void button3_Click(object sender, EventArgs e)
        {

            FrmComponente componente = new FrmComponente();
            PosicaoJanela.Copiar(this, componente);
            componente.Show();
            Close();
        
        }

        private void button2_Click(object sender, EventArgs e)
        {

            if (string.IsNullOrWhiteSpace(textBox2.Text))
            {

                MessageBox.Show("Preencha o ID do fusível.");
                textBox2.Focus();
                return;
            
            }


            using (MySqlConnection conn = new MySqlConnection(conexaoString))
            {

                conn.Open();

                string sqlSelect = "select quantidade_estoque from fusiveis where id = @id";
                
                MySqlCommand cmdSelect = new MySqlCommand(sqlSelect, conn);
                cmdSelect.Parameters.AddWithValue("@id", textBox2.Text);

                object result = cmdSelect.ExecuteScalar();

                if (result == null)
                {

                    MessageBox.Show("Fusível não encontrado.");
                    return;
                
                }

                int quantidade = Convert.ToInt32(result);

                if (quantidade > 0)
                {

                    string sqlDelete = "delete from fusiveis where id = @id";
                    
                    MySqlCommand cmdDelete = new MySqlCommand(sqlDelete, conn);
                    cmdDelete.Parameters.AddWithValue("@id", textBox2.Text);
                    cmdDelete.ExecuteNonQuery();

                    MessageBox.Show("Fusível removido totalmente do estoque.");
                
                }
                else
                {

                    MessageBox.Show("Nenhum fusível encontrado para exclusão.");
               
                }


                CarregarFusivel();
                textBox2.Clear();
            
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {

           
            if (string.IsNullOrWhiteSpace(textBox1.Text))
            {

                MessageBox.Show("Preencha a amperagem.");
                textBox1.Focus();
                return;
            
            }


            if (!int.TryParse(textBox1.Text, out int amperagem) || amperagem <= 0)
            {

                MessageBox.Show("Digite uma amperagem válida (número inteiro).");
                textBox1.Focus();
                return;
           
            }


            if (amperagem % 5 != 0)
            {


                MessageBox.Show("A amperagem deve ser múltiplo de 5 (5, 10, 15, 20...).");
                textBox1.Focus();
                return;
            
            
            }

           
            if (!int.TryParse(textBox3.Text, out int quantidadeAdicionar) || quantidadeAdicionar <= 0)
            {


                MessageBox.Show("Digite uma quantidade válida.");
                textBox3.Focus();
                return;
            
           
            }



            using (MySqlConnection conn = new MySqlConnection(conexaoString))
            {

                conn.Open();

                string amperagemFormatada = amperagem + " A";

                string sqlSelect = "select id from fusiveis where amperagem = @amperagem";
                
                MySqlCommand cmdSelect = new MySqlCommand(sqlSelect, conn);
                cmdSelect.Parameters.AddWithValue("@amperagem", amperagemFormatada);

                object result = cmdSelect.ExecuteScalar();


                if (result != null)
                {

                    string sqlUpdate = "update fusiveis set quantidade_estoque = quantidade_estoque + @qtd where id = @id";
                    
                    MySqlCommand cmdUpdate = new MySqlCommand(sqlUpdate, conn);
                    cmdUpdate.Parameters.AddWithValue("@id", result);
                    cmdUpdate.Parameters.AddWithValue("@qtd", quantidadeAdicionar);
                    cmdUpdate.ExecuteNonQuery();

                    MessageBox.Show($"Estoque atualizado +{quantidadeAdicionar} unidade(s)!");
                
                }
                else
                {


                    string sqlInsert = "insert into fusiveis (amperagem, quantidade_estoque) values (@amperagem, @qtd)";
                    
                    MySqlCommand cmdInsert = new MySqlCommand(sqlInsert, conn);
                    cmdInsert.Parameters.AddWithValue("@amperagem", amperagemFormatada);
                    cmdInsert.Parameters.AddWithValue("@qtd", quantidadeAdicionar);
                    cmdInsert.ExecuteNonQuery();

                    MessageBox.Show("Fusível adicionado com sucesso!");
                
                }

                CarregarFusivel();
                textBox1.Clear();
                textBox3.Clear();
            }
        }

        private void CarregarFusivel()
        {
            using (MySqlConnection conn = new MySqlConnection(conexaoString))
            {

                conn.Open();

                MySqlDataAdapter da = new MySqlDataAdapter("select * from fusiveis", conn);
                
                DataTable dt = new DataTable();
                
                da.Fill(dt);
                dataGridView1.DataSource = dt;
            }
        }
    }
}
