﻿using Microsoft.VisualBasic.Logging;
using MySql.Data.MySqlClient;
using System;
using System.Data;
using System.Windows.Forms;

namespace Projeto_Final
{
    public partial class FrmTransistorAdd : Form
    {
        string conexaoString = "server=localhost;database=trabalho_web_programacao;uid=root;pwd=;";

        public FrmTransistorAdd()
        {
            InitializeComponent();
            CarregarTransistores();
        }

        private void CarregarTransistores()
        {
            using (MySqlConnection conn = new MySqlConnection(conexaoString))
            {

                conn.Open();
                
                string sqlSelect = "select * from transistores";
                
                MySqlDataAdapter da = new MySqlDataAdapter(sqlSelect, conn);
                DataTable dt = new DataTable();
                
                da.Fill(dt);
                dataGridView1.DataSource = dt;
            
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(textBox1.Text))
            {

                MessageBox.Show("Preencha o modelo do transistor.");
                textBox1.Focus();
                return;
            
            }

            if (!int.TryParse(textBox6.Text, out int quantidadeAdicionar) || quantidadeAdicionar <= 0)
            {

                MessageBox.Show("Digite uma quantidade válida.");
                textBox6.Focus();
                return;
            
            }

            using (MySqlConnection conn = new MySqlConnection(conexaoString))
            {

                conn.Open();

                string modelo = textBox1.Text.Trim().ToUpper();
                string sqlSelect = "select id from transistores where modelo = @modelo";
                MySqlCommand cmdSelect = new MySqlCommand(sqlSelect, conn);
                cmdSelect.Parameters.AddWithValue("@modelo", modelo);

                object result = cmdSelect.ExecuteScalar();

                if (result != null)
                {

                    string sqlUpdate = "update transistores set quantidade_estoque = quantidade_estoque + @qtd where id = @id";
                    
                    MySqlCommand cmdUpdate = new MySqlCommand(sqlUpdate, conn);
                    cmdUpdate.Parameters.AddWithValue("@qtd", quantidadeAdicionar);
                    cmdUpdate.Parameters.AddWithValue("@id", result);
                    cmdUpdate.ExecuteNonQuery();

                    MessageBox.Show($"Estoque atualizado +{quantidadeAdicionar} unidade(s)!");
                
                }
                else
                {

                    string sqlInsert = "insert into transistores (modelo, quantidade_estoque) values (@modelo, @qtd)";
                    
                    MySqlCommand cmdInsert = new MySqlCommand(sqlInsert, conn);
                    
                    cmdInsert.Parameters.AddWithValue("@modelo", modelo);
                    cmdInsert.Parameters.AddWithValue("@qtd", quantidadeAdicionar);
                    cmdInsert.ExecuteNonQuery();

                    MessageBox.Show("Transistor adicionado com sucesso!");
                }

                CarregarTransistores();
                textBox1.Clear();
                textBox6.Clear();
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(textBox2.Text))
            {

                MessageBox.Show("Preencha o ID do transistor.");
                textBox2.Focus();
                return;
            
            }

            using (MySqlConnection conn = new MySqlConnection(conexaoString))
            {
                conn.Open();

                string sqlSelect = "select quantidade_estoque from transistores where id = @id";
                
                MySqlCommand cmdSelect = new MySqlCommand(sqlSelect, conn);
                cmdSelect.Parameters.AddWithValue("@id", textBox2.Text);

                object result = cmdSelect.ExecuteScalar();
                if (result == null)
                {

                    MessageBox.Show("Transistor não encontrado.");
                    return;
                
                }

                int quantidade = Convert.ToInt32(result);
                if (quantidade > 0)
                {
                    string sqlDelete = "delete from transistores where id = @id";

                    MySqlCommand cmdDelete = new MySqlCommand(sqlDelete, conn);
                    cmdDelete.Parameters.AddWithValue("@id", textBox2.Text);
                    cmdDelete.ExecuteNonQuery();

                    MessageBox.Show("Transistor removido totalmente do estoque.");
                }
                else
                {
                    MessageBox.Show("Nenhum transistor encontrado para exclusão.");
                }

                CarregarTransistores();
                textBox2.Clear();
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {

            FrmComponente admin = new FrmComponente();
            PosicaoJanela.Copiar(this, admin);
            admin.Show();
            Close();
        
        }
    }
}
