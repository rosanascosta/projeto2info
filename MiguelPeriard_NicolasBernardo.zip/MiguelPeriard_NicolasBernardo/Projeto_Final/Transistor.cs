﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Projeto_Final
{
    public partial class FrmFusivel : Form
    {
        public FrmFusivel()
        {
            InitializeComponent();
        }

        private void Transistor_Load(object sender, EventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {
            FrmAmperagem Amperagem = new FrmAmperagem();
            PosicaoJanela.Copiar(this, Amperagem);
            Amperagem.Show();
            this.Hide();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            FrmAmperagemPronta4 Amperagem = new FrmAmperagemPronta4();
            PosicaoJanela.Copiar(this,Amperagem);
            Amperagem.Show();
            this.Hide();
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            FrmEscolha Escolha = new FrmEscolha();
            PosicaoJanela.Copiar(this,Escolha);
            Escolha.Show();
            Close();
        }
    }
}
