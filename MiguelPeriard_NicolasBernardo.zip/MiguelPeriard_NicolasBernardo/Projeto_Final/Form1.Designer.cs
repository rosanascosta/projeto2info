﻿namespace Projeto_Final
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            menuStrip1 = new MenuStrip();
            cadastroToolStripMenuItem = new ToolStripMenuItem();
            registorToolStripMenuItem = new ToolStripMenuItem();
            escolhaToolStripMenuItem = new ToolStripMenuItem();
            componeteToolStripMenuItem = new ToolStripMenuItem();
            transistorToolStripMenuItem = new ToolStripMenuItem();
            resistorToolStripMenuItem = new ToolStripMenuItem();
            menuStrip1.SuspendLayout();
            SuspendLayout();
            // 
            // menuStrip1
            // 
            menuStrip1.Items.AddRange(new ToolStripItem[] { cadastroToolStripMenuItem, escolhaToolStripMenuItem });
            menuStrip1.Location = new Point(0, 0);
            menuStrip1.Name = "menuStrip1";
            menuStrip1.Size = new Size(800, 24);
            menuStrip1.TabIndex = 0;
            menuStrip1.Text = "menuStrip1";
            // 
            // cadastroToolStripMenuItem
            // 
            cadastroToolStripMenuItem.DropDownItems.AddRange(new ToolStripItem[] { registorToolStripMenuItem });
            cadastroToolStripMenuItem.Name = "cadastroToolStripMenuItem";
            cadastroToolStripMenuItem.Size = new Size(66, 20);
            cadastroToolStripMenuItem.Text = "Cadastro";
            // 
            // registorToolStripMenuItem
            // 
            registorToolStripMenuItem.Name = "registorToolStripMenuItem";
            registorToolStripMenuItem.Size = new Size(180, 22);
            registorToolStripMenuItem.Text = "Registor";
            registorToolStripMenuItem.Click += registorToolStripMenuItem_Click;
            // 
            // escolhaToolStripMenuItem
            // 
            escolhaToolStripMenuItem.DropDownItems.AddRange(new ToolStripItem[] { componeteToolStripMenuItem });
            escolhaToolStripMenuItem.Name = "escolhaToolStripMenuItem";
            escolhaToolStripMenuItem.Size = new Size(59, 20);
            escolhaToolStripMenuItem.Text = "Escolha";
            // 
            // componeteToolStripMenuItem
            // 
            componeteToolStripMenuItem.DropDownItems.AddRange(new ToolStripItem[] { transistorToolStripMenuItem, resistorToolStripMenuItem });
            componeteToolStripMenuItem.Name = "componeteToolStripMenuItem";
            componeteToolStripMenuItem.Size = new Size(180, 22);
            componeteToolStripMenuItem.Text = "Componete";
            // 
            // transistorToolStripMenuItem
            // 
            transistorToolStripMenuItem.Name = "transistorToolStripMenuItem";
            transistorToolStripMenuItem.Size = new Size(124, 22);
            transistorToolStripMenuItem.Text = "Transistor";
            // 
            // resistorToolStripMenuItem
            // 
            resistorToolStripMenuItem.Name = "resistorToolStripMenuItem";
            resistorToolStripMenuItem.Size = new Size(124, 22);
            resistorToolStripMenuItem.Text = "Resistor";
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(menuStrip1);
            MainMenuStrip = menuStrip1;
            Name = "Form1";
            Text = "Form1";
            menuStrip1.ResumeLayout(false);
            menuStrip1.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private MenuStrip menuStrip1;
        private ToolStripMenuItem cadastroToolStripMenuItem;
        private ToolStripMenuItem registorToolStripMenuItem;
        private ToolStripMenuItem escolhaToolStripMenuItem;
        private ToolStripMenuItem componeteToolStripMenuItem;
        private ToolStripMenuItem transistorToolStripMenuItem;
        private ToolStripMenuItem resistorToolStripMenuItem;
        private ToolStripMenuItem toolStripMenuItem1;
    }
}
