﻿using Microsoft.VisualBasic.Logging;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Projeto_Final
{
    public partial class FrmEscolhaAdmin : Form
    {
        public FrmEscolhaAdmin()
        {
            InitializeComponent();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            FrmAddUsuario add = new FrmAddUsuario();
            PosicaoJanela.Copiar(this, add);
            add.Show();
            Close();
        }

        private void button7_Click(object sender, EventArgs e)
        {
            FrmComponente add = new FrmComponente();
            PosicaoJanela.Copiar(this, add);
            add.Show();
            Close();
        }

        private void button8_Click(object sender, EventArgs e)
        {
            FrmRegistro admin = new FrmRegistro();
            PosicaoJanela.Copiar(this, admin);
            admin.Show();
            Close();
        }

        private void FrmEscolhaAdmin_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            FrmEmpréstimos emprestimo = new FrmEmpréstimos();
            PosicaoJanela.Copiar(this, emprestimo);
            emprestimo.Show();
            Close();
        }
    }
}
