﻿using Microsoft.VisualBasic.Logging;
using Microsoft.Win32;
using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.DataFormats;

namespace Projeto_Final
{
    public partial class FrmLogin : Form
    {


        string conexaoString = "server=localhost;database=trabalho_web_programacao;uid=root;pwd=;";
        public FrmLogin()
        {
            InitializeComponent();
        }


        private void button1_Click(object sender, EventArgs e)
        {
            string usuario = textBox1.Text.Trim();
            string senha = textBox2.Text.Trim();

            if (string.IsNullOrWhiteSpace(usuario) || string.IsNullOrWhiteSpace(senha))
            {
                MessageBox.Show("Preencha usuário e senha.", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            using (MySqlConnection conn = new MySqlConnection(conexaoString))
            {
                try
                {
                    conn.Open();

                    
                    string sql = "select cpf from usuarios where nome = @usuario and senha = @senha and tipo = 'usuario_comum'";

                    MySqlCommand cmd = new MySqlCommand(sql, conn);
                    cmd.Parameters.AddWithValue("@usuario", usuario);
                    cmd.Parameters.AddWithValue("@senha", senha);

                    object result = cmd.ExecuteScalar();

                    if (result != null)
                    {
                        string cpfDoUsuario = result.ToString();
                        ClasseNome.NomeUsuario = usuario;
                        ClasseCPF.CPF = cpfDoUsuario;

                        MessageBox.Show("Login realizado com sucesso", "Sucesso", MessageBoxButtons.OK, MessageBoxIcon.Information);

                        FrmEscolha escolha = new FrmEscolha();
                        PosicaoJanela.Copiar(this, escolha);
                        escolha.Show();
                        this.Hide();
                    }
                    else
                    {
                        MessageBox.Show("Usuário ou senha incorretos", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        textBox2.Clear();
                        textBox1.Focus();
                    }
                }

                catch (Exception ex)
                
                {

                    MessageBox.Show("Erro ao conectar ao banco de dados: " + ex.Message, "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                
                }
            }
        }


        private void button2_Click(object sender, EventArgs e)
        {
            FrmRegistro Registro = new FrmRegistro();
            PosicaoJanela.Copiar(this, Registro);
            Registro.Show();
            this.Hide();
        }

        private void FrmLogin_Load(object sender, EventArgs e)
        {

        }
    }

}
