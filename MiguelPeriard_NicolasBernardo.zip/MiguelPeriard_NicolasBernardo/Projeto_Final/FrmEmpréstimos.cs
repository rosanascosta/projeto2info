﻿using Microsoft.VisualBasic.Logging;
using MySql.Data.MySqlClient;
using System;
using System.Data;
using System.Windows.Forms;

namespace Projeto_Final
{
    public partial class FrmEmpréstimos : Form
    {
        string conexaoString = "server=localhost;database=trabalho_web_programacao;uid=root;pwd=;";

        public FrmEmpréstimos()
        {

            InitializeComponent();
        }

        private void FrmEmpréstimos_Load(object sender, EventArgs e)
        {

            CarregarAfiliacoes();
        }

        private void CarregarAfiliacoes()
        {
            try
            {
                using (var conn = new MySqlConnection(conexaoString))
                {

                    conn.Open();

                    string sqlSelect = "select * from Dados_do_cliente";

                    using (var da = new MySqlDataAdapter(sqlSelect, conn))
                    {

                        DataTable dt = new DataTable();
                        da.Fill(dt);

                        dataGridView1.DataSource = dt;
                        dataGridView1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
                        dataGridView1.ReadOnly = true;
                        dataGridView1.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
                    
                    }
                }
            }

            catch (Exception ex)

            {

                MessageBox.Show("Erro ao carregar os empréstimos: " + ex.Message);

            }
        
        }

        private void FiltrarPorNome(string nome)
        {

            try
            {

                using (var conn = new MySqlConnection(conexaoString))
                {

                    conn.Open();

                    string sqlSelect = "select * from Dados_do_cliente where nome like @nome";

                    using (var cmd = new MySqlCommand(sqlSelect, conn))
                    {
                        cmd.Parameters.AddWithValue("@nome", "%" + nome + "%");

                        using (var da = new MySqlDataAdapter(cmd))
                        {

                            DataTable dt = new DataTable();
                            da.Fill(dt);
                            dataGridView1.DataSource = dt;

                        }

                    }

                    dataGridView1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
                    dataGridView1.ReadOnly = true;
                    dataGridView1.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
                }
            }

            catch (Exception ex)
            
            {

                MessageBox.Show("Erro ao filtrar: " + ex.Message);
           
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {

            FrmEscolhaAdmin Resistor = new FrmEscolhaAdmin();
            PosicaoJanela.Copiar(this, Resistor);
            Resistor.Show();
            Close();

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

            FiltrarPorNome(textBox1.Text);

        }
    }
}
