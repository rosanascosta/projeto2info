﻿using Microsoft.VisualBasic.Logging;
using MySql.Data.MySqlClient;
using System;
using System.Data;
using System.Windows.Forms;

namespace Projeto_Final
{
    public partial class FrmResistorAdd : Form
    {
        string conexaoString = "server=localhost;database=trabalho_web_programacao;uid=root;pwd=;";

        public FrmResistorAdd()
        {

            InitializeComponent();
            CarregarResistor();

        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(textBox1.Text))
            {

                MessageBox.Show("Preencha a resistência do resistor.");
                textBox1.Focus();
                return;

            }

            if (string.IsNullOrWhiteSpace(textBox4.Text))
            {

                MessageBox.Show("Preencha a tolerância.");
                textBox4.Focus();
                return;

            }

            if (!int.TryParse(textBox6.Text, out int quantidadeAdicionar) || quantidadeAdicionar <= 0)
            {

                MessageBox.Show("Digite uma quantidade válida.");
                textBox6.Focus();
                return;

            }

            using (MySqlConnection conn = new MySqlConnection(conexaoString))
            {

                conn.Open();

                string resistenciaFormatada = textBox1.Text + " Ω";
                string toleranciaFormatada = textBox4.Text + "%";

                string sqlSelect = "select id from resistores where resistencia_eletrica = @resistencia and tolerancia = @tolerancia";
                
                MySqlCommand cmdSelect = new MySqlCommand(sqlSelect, conn);
                cmdSelect.Parameters.AddWithValue("@resistencia", resistenciaFormatada);
                cmdSelect.Parameters.AddWithValue("@tolerancia", toleranciaFormatada);

                object result = cmdSelect.ExecuteScalar();

                if (result != null)
                {

                    string sqlUpdate = "update resistores set quantidade_estoque = quantidade_estoque + @qtd where resistencia_eletrica = @resistencia and tolerancia = @tolerancia";
                    
                    MySqlCommand cmdUpdate = new MySqlCommand(sqlUpdate, conn);
                    
                    cmdUpdate.Parameters.AddWithValue("@resistencia", resistenciaFormatada);
                    cmdUpdate.Parameters.AddWithValue("@tolerancia", toleranciaFormatada);
                    cmdUpdate.Parameters.AddWithValue("@qtd", quantidadeAdicionar);
                    cmdUpdate.ExecuteNonQuery();

                    MessageBox.Show($"Estoque atualizado +{quantidadeAdicionar} unidade(s)!");
                
                }
                else
                {

                    string sqlInsert = "insert into resistores (resistencia_eletrica, tolerancia, quantidade_estoque) values (@resistencia, @tolerancia, @qtd)";
                    
                    MySqlCommand cmdInsert = new MySqlCommand(sqlInsert, conn);
                    
                    cmdInsert.Parameters.AddWithValue("@resistencia", resistenciaFormatada);
                    cmdInsert.Parameters.AddWithValue("@tolerancia", toleranciaFormatada);
                    cmdInsert.Parameters.AddWithValue("@qtd", quantidadeAdicionar);
                    cmdInsert.ExecuteNonQuery();

                    MessageBox.Show("Resistor adicionado com sucesso!");
                
                }

                CarregarResistor();
                textBox1.Clear();
                textBox4.Clear();
                textBox6.Clear();

            }
        }

        private void CarregarResistor()
        {
            using (MySqlConnection conn = new MySqlConnection(conexaoString))
            {
                conn.Open();
                
                MySqlDataAdapter da = new MySqlDataAdapter("select * from resistores", conn);
                DataTable dt = new DataTable();
                
                da.Fill(dt);
                dataGridView1.DataSource = dt;
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {

            if (string.IsNullOrWhiteSpace(textBox2.Text))
            {

                MessageBox.Show("Preencha o ID do resistor.");
                textBox2.Focus();
                return;
            
            }

            using (MySqlConnection conn = new MySqlConnection(conexaoString))
            {
                conn.Open();

                string sqlSelect = "select quantidade_estoque from resistores where id = @id";
                
                MySqlCommand cmdSelect = new MySqlCommand(sqlSelect, conn);
                cmdSelect.Parameters.AddWithValue("@id", textBox2.Text);

                object result = cmdSelect.ExecuteScalar();


                if (result == null)
                {

                    MessageBox.Show("Resistor não encontrado.");
                    return;
                
                }

                int quantidade = Convert.ToInt32(result);

                if (quantidade > 0)
                {

                    string sqlDelete = "delete from resistores where id = @id";
                    
                    MySqlCommand cmdDelete = new MySqlCommand(sqlDelete, conn);
                    cmdDelete.Parameters.AddWithValue("@id", textBox2.Text);
                    cmdDelete.ExecuteNonQuery();

                    MessageBox.Show("Item removido totalmente do estoque.");
                
                }
                else
                {

                    MessageBox.Show("Nenhum item encontrado para exclusão.");
                
                }

                CarregarResistor();
                textBox2.Clear();
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            
            FrmComponente admin = new FrmComponente();
            PosicaoJanela.Copiar(this, admin);
            admin.Show();
            Close();

        }
    }
}
