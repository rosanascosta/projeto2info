﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Projeto_Final
{
    public partial class FrmResistorPronto : Form
    {
        private double resistencia;
        private string tolerancia;

        public FrmResistorPronto()
        {
            InitializeComponent();

            textBox1.Text = "";
            textBox2.Text = "";

        }




        private void FrmResistorPronto_Load(object sender, EventArgs e)
        {

        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            FrmResistor Resistor = new FrmResistor();
            PosicaoJanela.Copiar(this, Resistor);
            Resistor.Show();
            Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            
            if (!double.TryParse(textBox1.Text, NumberStyles.Any, CultureInfo.InvariantCulture, out resistencia))
            {
                MessageBox.Show("Digite uma resistência válida.");
                return;
            }

            if (!int.TryParse(textBox2.Text, out int tol))
            {
                MessageBox.Show("Digite uma tolerância válida.");
                return;
            }

            tolerancia = tol.ToString();


            FrmLocalização Localizacao = new FrmLocalização("resistor", resistencia.ToString(CultureInfo.InvariantCulture) + " Ω", tolerancia + " %");
            PosicaoJanela.Copiar(this,Localizacao);
            Localizacao.Show();
            Close();
        }


        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
