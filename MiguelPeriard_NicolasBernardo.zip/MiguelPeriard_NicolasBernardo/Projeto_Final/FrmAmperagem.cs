﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Projeto_Final
{
    public partial class FrmAmperagem : Form
    {
        public FrmAmperagem()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            textBox1.Text = "";
            textBox2.Text = "";

        }

        private void button1_Click(object sender, EventArgs e)
        {
            double n1, n2;

            if (!double.TryParse(textBox1.Text, out n1) || !double.TryParse(textBox2.Text, out n2))
            {
                MessageBox.Show("Digite apenas números válidos.");
                return;
            }

            double resulte = n2 / n1;


            double arredondado = Math.Ceiling(resulte / 5) * 5;


            string amperagemCalculada = arredondado.ToString("0", CultureInfo.InvariantCulture);


            FrmLocalização localizacao = new FrmLocalização("fusivel", amperagemCalculada);
            PosicaoJanela.Copiar(this,localizacao );
            localizacao.Show();
            this.Hide();
        }

        private void button2_Click_1(object sender, EventArgs e)
        {
            FrmFusivel cores = new FrmFusivel();
            PosicaoJanela.Copiar(this, cores);
            cores.Show();
            Close();
        }
    }
}
