using Microsoft.VisualBasic.Logging;

namespace Projeto_Final
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void registorToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FrmRegistro registor = new FrmRegistro();
            registor.Show();
        }

        private void loginToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FrmLogin login = new FrmLogin();
            login.Show();
        }


    }
}
