﻿using Microsoft.VisualBasic.Logging;
using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Projeto_Final
{
    public partial class FrmAdmin : Form
    {
        

        string conexaoString = "server=localhost;database=trabalho_web_programacao;uid=root;pwd=;";

        public FrmAdmin()
        {

            InitializeComponent();

        }
       

        

        private void button1_Click(object sender, EventArgs e)
        {
            string usuario = textBox1.Text.Trim();
            string senha = textBox2.Text.Trim();


            if (usuario == "admin" && senha == "cefet123")
            {

                MessageBox.Show("Login realizado com sucesso", "Sucesso", MessageBoxButtons.OK, MessageBoxIcon.Information);

                FrmEscolhaAdmin escolha = new FrmEscolhaAdmin();
                PosicaoJanela.Copiar(this, escolha);
                escolha.Show();
                this.Hide();
                return;

            }


            using (MySqlConnection conn = new MySqlConnection(conexaoString))
            {
                try
                {

                    conn.Open();

                    string sql = "select count(*) from usuarios where nome = @usuario and senha = @senha and tipo = 'administrador'";

                    MySqlCommand cmd = new MySqlCommand(sql, conn);
                    
                    cmd.Parameters.AddWithValue("@usuario", usuario);
                    cmd.Parameters.AddWithValue("@senha", senha);

                    int count = Convert.ToInt32(cmd.ExecuteScalar());

                    if (count > 0)
                    {

                        MessageBox.Show("Login realizado com sucesso", "Sucesso", MessageBoxButtons.OK, MessageBoxIcon.Information);

                        FrmEscolhaAdmin escolha = new FrmEscolhaAdmin();
                        PosicaoJanela.Copiar(this, escolha);
                        escolha.Show();
                        this.Hide();

                    }
                    else
                    {

                        MessageBox.Show("Usuário ou senha incorretos", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        textBox2.Clear();
                        textBox1.Focus();

                    }
                }

                catch (Exception ex)

                {

                    MessageBox.Show("Erro ao conectar ao banco de dados: " + ex.Message, "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);

                }

            }

        }


        private void button2_Click_1(object sender, EventArgs e)
        {
            FrmRegistro escolha = new FrmRegistro();
            PosicaoJanela.Copiar(this, escolha);
            escolha.Show();
            Close();
        }
    }

}
