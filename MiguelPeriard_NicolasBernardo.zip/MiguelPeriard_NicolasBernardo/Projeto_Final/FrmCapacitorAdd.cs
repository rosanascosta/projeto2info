﻿using MySql.Data.MySqlClient;
using System;
using System.Data;
using System.Windows.Forms;

namespace Projeto_Final
{
    public partial class FrmCapacitorAdd : Form
    {
        string conexaoString = "server=localhost;database=trabalho_web_programacao;uid=root;pwd=;";

        public FrmCapacitorAdd()
        {
            InitializeComponent();
            CarregarCapacitores();
        }

        private void CarregarCapacitores()
        {
            using (MySqlConnection conn = new MySqlConnection(conexaoString))
            {

                conn.Open();
                MySqlDataAdapter da = new MySqlDataAdapter("select * from capacitores", conn);
                DataTable dt = new DataTable();
                da.Fill(dt);
                dataGridView1.DataSource = dt;
            
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(textBox1.Text))
            {

                MessageBox.Show("Preencha a voltagem do capacitor.");
                textBox1.Focus();
                return;
            
            }

            if (string.IsNullOrWhiteSpace(textBox4.Text))
            {

                MessageBox.Show("Preencha o valor em microfarads (uF).");
                textBox4.Focus();
                return;
            
            }

            if (!int.TryParse(textBox6.Text, out int quantidadeAdicionar) || quantidadeAdicionar <= 0)
            {

                MessageBox.Show("Digite uma quantidade válida.");
                textBox6.Focus();
                return;
            
            }

            string voltagem = textBox1.Text.Trim() + " V";
            string especificacao = textBox4.Text.Trim() + " uF";

            using (MySqlConnection conn = new MySqlConnection(conexaoString))
            {
                conn.Open();

                string sqlSelect = "select id from capacitores where voltagem = @v and especificacoes_uF = @uF";
                
                MySqlCommand cmdSelect = new MySqlCommand(sqlSelect, conn);
                cmdSelect.Parameters.AddWithValue("@v", voltagem);
                cmdSelect.Parameters.AddWithValue("@uF", especificacao);

                object result = cmdSelect.ExecuteScalar();

                if (result != null)
                {

                    string sqlUpdate = "update capacitores set quantidade_estoque = quantidade_estoque + @qtd where id = @id";
                    MySqlCommand cmdUpdate = new MySqlCommand(sqlUpdate, conn);
                    cmdUpdate.Parameters.AddWithValue("@qtd", quantidadeAdicionar);
                    cmdUpdate.Parameters.AddWithValue("@id", result);
                    cmdUpdate.ExecuteNonQuery();

                    MessageBox.Show($"Estoque atualizado +{quantidadeAdicionar} unidade(s)!");
                
                }
                else
                {

                    string sqlInsert = "insert into capacitores (voltagem, especificacoes_uF, quantidade_estoque) values (@v, @uF, @qtd)";
                    MySqlCommand cmdInsert = new MySqlCommand(sqlInsert, conn);
                    cmdInsert.Parameters.AddWithValue("@v", voltagem);
                    cmdInsert.Parameters.AddWithValue("@uF", especificacao);
                    cmdInsert.Parameters.AddWithValue("@qtd", quantidadeAdicionar);
                    cmdInsert.ExecuteNonQuery();

                    MessageBox.Show("Capacitor adicionado com sucesso!");
                }

                CarregarCapacitores();
                textBox1.Clear();
                textBox4.Clear();
                textBox6.Clear();
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {

            if (string.IsNullOrWhiteSpace(textBox2.Text))
            {

                MessageBox.Show("Informe o ID do capacitor.");
                textBox2.Focus();
                return;
           
            }

            using (MySqlConnection conn = new MySqlConnection(conexaoString))
            {
                conn.Open();

                string sqlSelect = "select quantidade_estoque from capacitores where id = @id";
                
                MySqlCommand cmdSelect = new MySqlCommand(sqlSelect, conn);
                cmdSelect.Parameters.AddWithValue("@id", textBox2.Text);

                object result = cmdSelect.ExecuteScalar();

                if (result == null)
                {

                    MessageBox.Show("Capacitor não encontrado.");
                    return;
                
                }

                int quantidade = Convert.ToInt32(result);

                if (quantidade > 0)
                {

                    string sqlDelete = "delete from capacitores where id = @id";
                    MySqlCommand cmdDelete = new MySqlCommand(sqlDelete, conn);
                    cmdDelete.Parameters.AddWithValue("@id", textBox2.Text);
                    cmdDelete.ExecuteNonQuery();

                    MessageBox.Show("Capacitor removido totalmente do estoque.");
                
                }
                else
                {

                    MessageBox.Show("Nenhum capacitor encontrado para exclusão.");
                
                }


                CarregarCapacitores();
                textBox2.Clear();
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {

            FrmComponente admin = new FrmComponente();
            PosicaoJanela.Copiar(this, admin);
            admin.Show();
            Close();
        
        }
    }
}
